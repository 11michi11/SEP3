import React, { Component } from 'react';

class Search extends Component {
    state = {  }
    render() { 
        return ( 
            <div>
                
            </div>
         );
    }
}
 
export default Search;