import controller.Controller;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.fail;

public class ControllerTest {
//
//    @Mock
//    private DBProxy db;
//    @Mock
//    private Server server;
//
//    @InjectMocks
    private Controller controller;

//    @BeforeEach
//    public void setup() {
//       // MockitoAnnotations.initMocks(this);
//        DBProxy db = RepositoryManager.getInstance();
//        Server server = new Server();
//        controller = new Controller(db, server);
//    }

//    @Test
//    void nullSearchTest(){
//        Map<String, Object> args = new HashMap<>();
//        args.put("isbn", null);
//        args.put("title", "Tolkien");
//        args.put("author", null);
//        args.put("year", null);
//        args.put("category", null);
//        args.put("libraryid", "ce78ef57-77ec-4bb7-82a2-1a78d3789aef");
//        Request request = new Request(Request.Operation.LibraryAdvancedSearch, args);
//
//        String resposne = null;
//        try {
//            resposne = controller.handleLibraryAdvancedSearch(request);
//        } catch (Controller.InvalidOperationException e) {
//            e.printStackTrace();
//        }
//
//        System.out.println(resposne);
//    }
//


}
