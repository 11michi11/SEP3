package model;

public interface Admin {

    public String getInstitutionId();

    String getServerUrl();
}
