package model;

public interface Institution {

}
