import controller.Controller;
import controller.connection.DatabaseProxy;
import model.Customer;
import org.junit.jupiter.api.BeforeEach;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;

import static org.junit.jupiter.api.Assertions.assertNotNull;
import static org.mockito.Mockito.when;

public class Test {
//    @Mock
//    private DatabaseProxy db;
//
//    @InjectMocks
//    private Controller controller;
//
//    @BeforeEach
//    public void setup() { MockitoAnnotations.initMocks(this); }
//
//    @Test
//    public void AddCustomerTest(){
//        Customer customer =new Customer("Daniela Koch","dani@via.dk","Sunny Street 44, 8700 Horsens", 00112233);
//        when(db.addCustomer(customer)).thenReturn("{\"status\":\"OK\",\"content\":\"Added\"}");
//        assertNotNull(controller.addCustomer(customer));
//    }

}
